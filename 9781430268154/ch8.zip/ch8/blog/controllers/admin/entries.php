<?php
//complete source code for controllers/admin/entries.php

return "<h1>entries controller loaded!</h1>";
