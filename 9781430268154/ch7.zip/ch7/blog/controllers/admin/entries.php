<?php

return "<h1>entries controller loaded!</h1>";
