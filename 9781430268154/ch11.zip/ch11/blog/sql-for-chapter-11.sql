create table admin(
    admin_id INT NOT NULL AUTO_INCREMENT,
    email TEXT,
    password VARCHAR(32),
    primary key (admin_id)
)
