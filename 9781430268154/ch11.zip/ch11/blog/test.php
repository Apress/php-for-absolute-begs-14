<?

phpinfo();
