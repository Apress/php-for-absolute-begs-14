<?php

return "
    <nav id='admin-navigation'>
        <a href='admin.php?page=entries'>All entries</a>
        <a href='admin.php?page=editor'>Editor</a>
    </nav>";
