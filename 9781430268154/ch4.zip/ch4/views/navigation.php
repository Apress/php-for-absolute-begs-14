<?php
return "
<nav>
    <a href='index.php?page=gallery'>Gallery</a>
    <a href='index.php?page=upload'>Upload new image</a>
</nav>
";
