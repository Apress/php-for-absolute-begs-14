<?php
return "
<nav>
    <a href='index.php?page=search'>Search on bing</a>
    <a href='index.php?page=quiz'>Dynamic quiz</a>
</nav>
";
