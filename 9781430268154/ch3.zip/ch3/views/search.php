<?php
return "
<form method='get' action='http://www.bing.com/search'>
    <input type='text' name='q' />
    <input type='submit' value='search on bing' />
</form>
";
