<?php
//complete code for views/admin/logout-form-html.php
return "
<form method='post' action='admin.php'>
    <label>logged in as administrator</label>
    <input type='submit' value='log out' name='logout' />
</form>";
