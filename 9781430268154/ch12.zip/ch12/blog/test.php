<?
//complete source code for test.php
phpinfo();
