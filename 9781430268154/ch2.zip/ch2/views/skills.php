<?php
return "<h1>Skills and educational background</h1>
<p>Read all about my skills and my formal training</p>
";
