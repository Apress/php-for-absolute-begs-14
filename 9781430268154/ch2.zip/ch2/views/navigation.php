<?php
return "
<nav>
    <a href='index.php?page=skills'>My skills and background</a>
    <a href='index.php?page=projects'>Some projects</a>
</nav>
";
